_G.UpdateThisMod = _G.UpdateThisMod or {}
if UpdateThisMod then
	UpdateThisMod:Add({
		mod_id = 'Hells Island Translate PT-BR',
		data = {
			modworkshop_id = 23779,
			dl_url = 'https://github.com/gabsF/bainbreakout-pt-br/raw/master/hell-island-translate-pt-br.zip',
			info_url = 'https://github.com/gabsF/bainbreakout-pt-br/raw/master/mod.txt',
		}
	})
	UpdateThisMod:Loop()
end